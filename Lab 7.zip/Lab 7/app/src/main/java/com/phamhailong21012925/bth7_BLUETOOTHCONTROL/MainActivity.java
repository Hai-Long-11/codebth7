package com.phamhailong21012925.bth7_BLUETOOTHCONTROL;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "BluetoothControl";
    private static final int REQUEST_BLUETOOTH_CONNECT = 1;
    private static final int REQUEST_BLUETOOTH_SCAN = 2;
    private static final int REQUEST_FINE_LOCATION = 3;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothManager bluetoothManager;
    private Intent intOnBLE;
    private ActivityResultLauncher<Intent> EnableBLE;
    private Button btON, btOFF, btScan;
    private ListView listview, scanListview;

    // ArrayLists để lưu trữ thiết bị
    private ArrayList<String> pairedDevicesList;  // Danh sách thiết bị đã ghép nối
    private ArrayList<String> newDevicesList;     // Danh sách thiết bị mới tìm thấy

    // Adapters để hiển thị lên ListView
    private ArrayAdapter<String> pairedDevicesAdapter;
    private ArrayAdapter<String> newDevicesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Gán đối tượng giao diện
        btON = findViewById(R.id.btON);
        btOFF = findViewById(R.id.btOFF);
        btScan = findViewById(R.id.btScan);
        listview = findViewById(R.id.listview);
        scanListview = findViewById(R.id.scanListview);

        // Khởi tạo ArrayList và ArrayAdapter
        pairedDevicesList = new ArrayList<>();
        newDevicesList = new ArrayList<>();

        // Khởi tạo adapters
        pairedDevicesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pairedDevicesList);
        newDevicesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, newDevicesList);

        // Gán adapters cho ListView
        listview.setAdapter(pairedDevicesAdapter);
        scanListview.setAdapter(newDevicesAdapter);

        // Khởi tạo BluetoothAdapter
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            bluetoothManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            bluetoothAdapter = bluetoothManager.getAdapter();
        } else {
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }

        // Kiểm tra và yêu cầu các quyền cần thiết
        requestRequiredPermissions();

        // Intent và launcher để bật Bluetooth
        intOnBLE = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        EnableBLE = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        int resultCode = result.getResultCode();
                        if (resultCode == RESULT_OK) {
                            Toast.makeText(getApplicationContext(), "Bluetooth started", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Bluetooth cannot start...", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );

        // Sự kiện bật Bluetooth
        btON.setOnClickListener(v -> handleBluetoothOn());

        // Sự kiện tắt Bluetooth
        btOFF.setOnClickListener(v -> handleBluetoothOff());

        // Sự kiện nhấn Scan
        btScan.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View view) {
                // Xóa danh sách thiết bị cũ
                pairedDevicesList.clear();
                newDevicesList.clear();

                // Báo hiệu cho adapter cập nhật giao diện
                pairedDevicesAdapter.notifyDataSetChanged();
                newDevicesAdapter.notifyDataSetChanged();

                // Hiển thị thiết bị đã ghép nối
                showPairedDevices();

                // Bắt đầu tìm kiếm thiết bị mới
                if (checkBluetoothPermissions()) {
                    Toast.makeText(MainActivity.this, "Đang tìm kiếm thiết bị mới...", Toast.LENGTH_SHORT).show();
                    bluetoothAdapter.startDiscovery();
                } else {
                    Toast.makeText(MainActivity.this, "Không đủ quyền để tìm kiếm thiết bị", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Đăng ký BroadcastReceiver để nhận thông báo khi tìm thấy thiết bị mới
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(discoveryReceiver, filter);

        // Thêm chức năng nhấn để chọn thiết bị và chuyển sang Bluetooth.java
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // Lấy adapter từ ListView
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) listview.getAdapter();

                // Lấy danh sách các mục từ adapter
                ArrayList<String> listItems = new ArrayList<>();
                for (int i = 0; i < adapter.getCount(); i++) {
                    listItems.add(adapter.getItem(i));
                }

                String selectedItem = listItems.get(position);
                String[] parts = selectedItem.split("\n");
                if (parts.length >= 2) {
                    String deviceName = parts[0];
                    String deviceAddress = parts[1];
                    Intent intent = new Intent(MainActivity.this, Bluetooth.class);
                    intent.putExtra("DEVICE_ADDRESS", deviceAddress);
                    startActivity(intent);
                }
            }
        });

        // Thêm chức năng nhấn giữ để bỏ ghép nối
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                String selectedItem = pairedDevicesList.get(position);
                String[] parts = selectedItem.split("\n");
                if (parts.length >= 2) {
                    String deviceAddress = parts[1];
                    BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                    unpairDevice(device);
                    pairedDevicesList.remove(position);
                    pairedDevicesAdapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Đã bỏ ghép nối thiết bị: " + parts[0], Toast.LENGTH_SHORT).show();
                }
                return true; // Để biểu thị rằng sự kiện đã được xử lý
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void unpairDevice(BluetoothDevice device) {
        try {
            Method method = device.getClass().getMethod("removeBond", (Class[]) null);
            method.invoke(device, (Object[]) null);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Không thể bỏ ghép nối thiết bị", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ cần quyền BLUETOOTH_CONNECT và BLUETOOTH_SCAN
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLUETOOTH_CONNECT);
            }

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_SCAN}, REQUEST_BLUETOOTH_SCAN);
            }
        }

        // Vị trí là cần thiết cho Bluetooth scan trên nhiều thiết bị
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_FINE_LOCATION);
        }
    }

    private boolean checkBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
    }

    @SuppressLint("MissingPermission")
    private void handleBluetoothOn() {
        if (bluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "Bluetooth not supported...", Toast.LENGTH_LONG).show();
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Toast.makeText(getApplicationContext(), "Bluetooth starting...", Toast.LENGTH_LONG).show();
                EnableBLE.launch(intOnBLE);
            } else {
                Toast.makeText(getApplicationContext(), "Bluetooth already started", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint("MissingPermission")
    private void handleBluetoothOff() {
        if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.disable();
            Toast.makeText(getApplicationContext(), "Bluetooth stopped", Toast.LENGTH_LONG).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                Intent disableBLE = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                startActivity(disableBLE);
            }
            Toast.makeText(getApplicationContext(), "Bluetooth already stopped", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Hủy quá trình tìm kiếm nếu đang diễn ra
        if (bluetoothAdapter != null && checkBluetoothPermissions()) {
            bluetoothAdapter.cancelDiscovery();
        }

        // Hủy đăng ký BroadcastReceiver
        try {
            unregisterReceiver(discoveryReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering receiver: " + e.getMessage());
        }
    }

    // Hiển thị thiết bị đã ghép nối
    @SuppressLint("MissingPermission")
    private void showPairedDevices() {
        if (!checkBluetoothPermissions()) {
            Toast.makeText(this, "Không đủ quyền để hiển thị các thiết bị", Toast.LENGTH_SHORT).show();
            return;
        }

        if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

            if (pairedDevices.size() > 0) {
                pairedDevicesList.clear(); // Xóa danh sách hiện tại trước khi thêm
                for (BluetoothDevice device : pairedDevices) {
                    String deviceInfo = device.getName() + "\n" + device.getAddress();
                    pairedDevicesList.add(deviceInfo);
                }
                pairedDevicesAdapter.notifyDataSetChanged();
                Log.d(TAG, "Đã tìm thấy " + pairedDevicesList.size() + " thiết bị đã ghép nối");
            } else {
                Toast.makeText(this, "Không có thiết bị nào đã ghép nối", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Bluetooth không được bật", Toast.LENGTH_SHORT).show();
        }
    }

    // BroadcastReceiver để phát hiện thiết bị Bluetooth mới
    private final BroadcastReceiver discoveryReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Lấy thông tin thiết bị từ Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                if (device != null) {
                    // Tạo thông tin thiết bị
                    String deviceName = device.getName();
                    String deviceAddress = device.getAddress();
                    String deviceInfo = (deviceName != null ? deviceName : "Unknown") + "\n" + deviceAddress;

                    // Kiểm tra xem thiết bị này đã ghép nối chưa
                    boolean isPaired = false;
                    for (String pairedDevice : pairedDevicesList) {
                        if (pairedDevice.contains(deviceAddress)) {
                            isPaired = true;
                            break;
                        }
                    }

                    // Thêm thiết bị vào danh sách thiết bị mới nếu chưa ghép nối
                    if (!isPaired && !newDevicesList.contains(deviceInfo)) {
                        newDevicesList.add(deviceInfo);
                        newDevicesAdapter.notifyDataSetChanged();
                        Log.d(TAG, "Tìm thấy thiết bị mới: " + deviceInfo);
                    }
                }
            }
        }
    };
}