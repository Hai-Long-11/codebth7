package com.phamhailong21012925.bth7_BLUETOOTHCONTROL;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start); // layout chứa ảnh Ronaldo

        // Hiển thị ảnh Ronaldo 2 giây, sau đó mới xử lý tiếp
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Sau khi hiển thị splash, kiểm tra quyền Bluetooth
                boolean start = StartPermission.requestBluetoothPermissions(StartActivity.this);
                if (start) {
                    new AlertDialog.Builder(StartActivity.this)
                            .setTitle("Yêu cầu quyền Bluetooth")
                            .setMessage("Bạn đã cấp quyền chưa?")
                            .setPositiveButton("Rồi", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    // Chuyển sang MainActivity
                                    Intent mainIntent = new Intent(StartActivity.this, MainActivity.class);
                                    startActivity(mainIntent);
                                    finish();
                                }
                            })
                            .setNegativeButton("Chưa", null)
                            .show();
                } else {
                    Toast.makeText(getApplicationContext(), "Đang chuyển sang ứng dụng...", Toast.LENGTH_SHORT).show();
                    Intent mainIntent = new Intent(StartActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                    finish();
                }
            }
        }, 2000); // 2 giây
    }
}
