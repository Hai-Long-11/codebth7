package com.phamhailong21012925.bth7_BLUETOOTHCONTROL;

import android.os.Build;
import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class StartPermission {

    public static boolean requestBluetoothPermissions(Activity activity) {
        boolean needPermission = false;

        // Check if the SDK version is 31 or above
        if (Build.VERSION.SDK_INT >= 31) {

            // Check for BLUETOOTH_CONNECT permission
            if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }

            // Check for ACCESS_FINE_LOCATION permission
            if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }

            // Check for BLUETOOTH_SCAN permission
            if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }

            // Request permissions if needed
            if (needPermission) {
                ActivityCompat.requestPermissions(activity, new String[]{
                        android.Manifest.permission.BLUETOOTH_CONNECT,
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.BLUETOOTH_SCAN
                }, 100); // Request code 100
            }
        }

        return needPermission;
    }
}